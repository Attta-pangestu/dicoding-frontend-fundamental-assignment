import main from './view/main.js' ; 
import './styles/style.css' ; 
import 'regenerator-runtime' ; 

document.addEventListener('DOMContentLoaded', main) ;